#pragma once

void default_constants();
void right_auton();
void left_auton();
void skills_auton();
void allAWP();

