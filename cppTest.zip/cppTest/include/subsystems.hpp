#pragma once

#include "EZ-Template/api.hpp"
#include "api.h"

extern ez::Drive chassis;

// Motors
inline pros::v5::Motor intake(11);
inline pros::v5::Motor scorer(12);

// Sensors (IMU)
inline pros::v5::IMU inertial(19);

// Pistons
inline ez::Piston matchloader('B', false);
inline ez::Piston descorer('C', true);
inline ez::Piston centerGoal('A', true);
